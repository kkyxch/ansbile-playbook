#define BUILDING_H264_STREAMING
#include "ngx_http_streaming_module.c"
